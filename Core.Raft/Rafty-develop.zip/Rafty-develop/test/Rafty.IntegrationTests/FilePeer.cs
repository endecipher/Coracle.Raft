namespace Rafty.IntegrationTests
{
    public class FilePeer
    {
        public string HostAndPort { get; set; }
    }
}
