﻿namespace Rafty.ManualTests
{
    using System;

    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("here we go again...");
        }
    }
}