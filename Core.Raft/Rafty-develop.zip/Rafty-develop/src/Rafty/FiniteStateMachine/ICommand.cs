﻿namespace Rafty.FiniteStateMachine
{
    public interface ICommand
    {
        
    }
}