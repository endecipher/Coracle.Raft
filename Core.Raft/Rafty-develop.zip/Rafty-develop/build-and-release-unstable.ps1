./build.ps1 -target BuildAndReleaseUnstable
exit $LASTEXITCODE